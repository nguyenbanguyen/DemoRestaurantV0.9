namespace DemoRestaurant.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class _442017 : DbMigration
    {
        public override void Up()
        {
        }
        
        public override void Down()
        {
        }
    }
}
