﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DemoRestaurant.Model
{
    public class AdminViewModel
    {
        public string UserName { get; set; }
    }
}